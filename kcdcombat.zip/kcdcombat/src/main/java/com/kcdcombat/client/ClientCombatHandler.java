package com.kcdcombat.client;

import com.kcdcombat.combat.CombatDirection;
import com.kcdcombat.network.NetworkHandler;
import com.kcdcombat.network.packets.C2SAttackDirectionPacket;
import com.kcdcombat.network.packets.C2SAttackReleasePacket;
import com.kcdcombat.network.packets.C2SAttackStartPacket;
import com.kcdcombat.network.packets.C2SBlockPacket;
import net.minecraft.client.Minecraft;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.glfw.GLFW;

import java.nio.DoubleBuffer;

/**
 * Polls raw cursor position each client tick (rather than hooking vanilla camera-turn deltas)
 * so direction selection works independently of look sensitivity/camera state.
 */
public class ClientCombatHandler {

    private double lastCursorX = Double.NaN;
    private double lastCursorY = Double.NaN;

    private boolean wasAttackDown = false;
    private boolean wasBlockDown = false;
    private boolean windingUp = false;

    private double accumDx = 0;
    private double accumDy = 0;
    private CombatDirection lastSentAttackDir = null;
    private CombatDirection lastSentBlockDir = null;

    // HUD-facing state, updated from server sync
    public static float clientStamina = 100f;
    public static float clientMaxStamina = 100f;

    public static void onStaminaSync(float stamina, float max) {
        clientStamina = stamina;
        clientMaxStamina = max;
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        double[] cx = new double[1];
        double[] cy = new double[1];
        GLFW.glfwGetCursorPos(mc.getWindow().getWindow(), cx, cy);

        double dx = 0, dy = 0;
        if (!Double.isNaN(lastCursorX)) {
            dx = cx[0] - lastCursorX;
            dy = cy[0] - lastCursorY;
        }
        lastCursorX = cx[0];
        lastCursorY = cy[0];

        boolean attackDown = KeyBindings.ATTACK.isDown();
        boolean blockDown = KeyBindings.BLOCK.isDown();

        // --- Attack windup / release ---
        if (attackDown && !wasAttackDown) {
            windingUp = true;
            accumDx = 0;
            accumDy = 0;
            lastSentAttackDir = null;
            NetworkHandler.CHANNEL.sendToServer(new C2SAttackStartPacket());
        }
        if (windingUp && attackDown) {
            accumDx += dx;
            accumDy += dy;
            CombatDirection dir = CombatDirection.fromMouseDelta(accumDx, accumDy, false);
            if (dir != lastSentAttackDir) {
                lastSentAttackDir = dir;
                NetworkHandler.CHANNEL.sendToServer(new C2SAttackDirectionPacket(dir));
            }
        }
        if (!attackDown && wasAttackDown) {
            windingUp = false;
            NetworkHandler.CHANNEL.sendToServer(new C2SAttackReleasePacket());
        }
        wasAttackDown = attackDown;

        // --- Block ---
        if (blockDown) {
            CombatDirection dir = CombatDirection.fromMouseDelta(dx * 6, dy * 6, false); // more sensitive since it's per-tick, not accumulated
            if (!wasBlockDown) {
                lastSentBlockDir = dir;
                NetworkHandler.CHANNEL.sendToServer(new C2SBlockPacket(true, dir));
            } else if (dir != lastSentBlockDir) {
                lastSentBlockDir = dir;
                NetworkHandler.CHANNEL.sendToServer(new C2SBlockPacket(true, dir));
            }
        } else if (wasBlockDown) {
            NetworkHandler.CHANNEL.sendToServer(new C2SBlockPacket(false, lastSentBlockDir == null ? CombatDirection.TOP : lastSentBlockDir));
        }
        wasBlockDown = blockDown;
    }
}
