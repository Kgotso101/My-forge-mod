package com.kcdcombat.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class KeyBindings {

    public static final String CATEGORY = "key.categories.kcdcombat";

    public static final KeyMapping ATTACK = new KeyMapping("key.kcdcombat.attack", KeyConflictContext.IN_GAME,
            InputConstants.Type.MOUSE, InputConstants.MOUSE_BUTTON_LEFT, CATEGORY);
    public static final KeyMapping BLOCK = new KeyMapping("key.kcdcombat.block", KeyConflictContext.IN_GAME,
            InputConstants.Type.MOUSE, InputConstants.MOUSE_BUTTON_RIGHT, CATEGORY);

    @SubscribeEvent
    public static void onRegister(RegisterKeyMappingsEvent event) {
        event.register(ATTACK);
        event.register(BLOCK);
    }
}
