package com.kcdcombat.network.packets;

import com.kcdcombat.combat.CombatDirection;
import com.kcdcombat.combat.CombatEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class C2SBlockPacket {

    private final boolean blocking;
    private final CombatDirection direction;

    public C2SBlockPacket(boolean blocking, CombatDirection direction) {
        this.blocking = blocking;
        this.direction = direction;
    }

    public static void encode(C2SBlockPacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.blocking);
        buf.writeEnum(msg.direction);
    }

    public static C2SBlockPacket decode(FriendlyByteBuf buf) {
        return new C2SBlockPacket(buf.readBoolean(), buf.readEnum(CombatDirection.class));
    }

    public static void handle(C2SBlockPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            if (ctx.get().getSender() != null) {
                CombatEvents.setBlocking(ctx.get().getSender(), msg.blocking, msg.direction);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
