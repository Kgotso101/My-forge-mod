package com.kcdcombat.network.packets;

import com.kcdcombat.combat.CombatEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class C2SAttackStartPacket {

    public C2SAttackStartPacket() {}

    public static void encode(C2SAttackStartPacket msg, FriendlyByteBuf buf) {}

    public static C2SAttackStartPacket decode(FriendlyByteBuf buf) {
        return new C2SAttackStartPacket();
    }

    public static void handle(C2SAttackStartPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            if (ctx.get().getSender() != null) {
                CombatEvents.startWindup(ctx.get().getSender());
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
