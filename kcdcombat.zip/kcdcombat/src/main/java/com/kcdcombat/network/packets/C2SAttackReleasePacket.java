package com.kcdcombat.network.packets;

import com.kcdcombat.combat.CombatEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class C2SAttackReleasePacket {

    public C2SAttackReleasePacket() {}

    public static void encode(C2SAttackReleasePacket msg, FriendlyByteBuf buf) {}

    public static C2SAttackReleasePacket decode(FriendlyByteBuf buf) {
        return new C2SAttackReleasePacket();
    }

    public static void handle(C2SAttackReleasePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            if (ctx.get().getSender() != null) {
                CombatEvents.releaseStrike(ctx.get().getSender());
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
