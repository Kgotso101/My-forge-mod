package com.kcdcombat.network;

import com.kcdcombat.KCDCombat;
import com.kcdcombat.network.packets.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class NetworkHandler {

    private static final String PROTOCOL_VERSION = "1";
    public static SimpleChannel CHANNEL;

    public static void register() {
        CHANNEL = NetworkRegistry.newSimpleChannel(
                new ResourceLocation(KCDCombat.MODID, "main"),
                () -> PROTOCOL_VERSION,
                PROTOCOL_VERSION::equals,
                PROTOCOL_VERSION::equals
        );

        int id = 0;
        CHANNEL.registerMessage(id++, C2SAttackStartPacket.class,
                C2SAttackStartPacket::encode, C2SAttackStartPacket::decode, C2SAttackStartPacket::handle);
        CHANNEL.registerMessage(id++, C2SAttackDirectionPacket.class,
                C2SAttackDirectionPacket::encode, C2SAttackDirectionPacket::decode, C2SAttackDirectionPacket::handle);
        CHANNEL.registerMessage(id++, C2SAttackReleasePacket.class,
                C2SAttackReleasePacket::encode, C2SAttackReleasePacket::decode, C2SAttackReleasePacket::handle);
        CHANNEL.registerMessage(id++, C2SBlockPacket.class,
                C2SBlockPacket::encode, C2SBlockPacket::decode, C2SBlockPacket::handle);
        CHANNEL.registerMessage(id++, S2CStaminaSyncPacket.class,
                S2CStaminaSyncPacket::encode, S2CStaminaSyncPacket::decode, S2CStaminaSyncPacket::handle);
    }
}
