package com.kcdcombat.network.packets;

import com.kcdcombat.combat.CombatDirection;
import com.kcdcombat.combat.CombatEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class C2SAttackDirectionPacket {

    private final CombatDirection direction;

    public C2SAttackDirectionPacket(CombatDirection direction) {
        this.direction = direction;
    }

    public static void encode(C2SAttackDirectionPacket msg, FriendlyByteBuf buf) {
        buf.writeEnum(msg.direction);
    }

    public static C2SAttackDirectionPacket decode(FriendlyByteBuf buf) {
        return new C2SAttackDirectionPacket(buf.readEnum(CombatDirection.class));
    }

    public static void handle(C2SAttackDirectionPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            if (ctx.get().getSender() != null) {
                CombatEvents.updateDirection(ctx.get().getSender(), msg.direction);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
