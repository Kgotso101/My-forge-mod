package com.kcdcombat.network.packets;

import com.kcdcombat.client.ClientCombatHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class S2CStaminaSyncPacket {

    private final float stamina;
    private final float maxStamina;

    public S2CStaminaSyncPacket(float stamina, float maxStamina) {
        this.stamina = stamina;
        this.maxStamina = maxStamina;
    }

    public static void encode(S2CStaminaSyncPacket msg, FriendlyByteBuf buf) {
        buf.writeFloat(msg.stamina);
        buf.writeFloat(msg.maxStamina);
    }

    public static S2CStaminaSyncPacket decode(FriendlyByteBuf buf) {
        return new S2CStaminaSyncPacket(buf.readFloat(), buf.readFloat());
    }

    public static void handle(S2CStaminaSyncPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> net.minecraftforge.fml.DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientCombatHandler.onStaminaSync(msg.stamina, msg.maxStamina)));
        ctx.get().setPacketHandled(true);
    }
}
