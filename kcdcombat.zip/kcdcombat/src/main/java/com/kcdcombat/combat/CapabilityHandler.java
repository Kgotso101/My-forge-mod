package com.kcdcombat.combat;

import com.kcdcombat.KCDCombat;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = KCDCombat.MODID)
public class CapabilityHandler {

    public static final ResourceLocation ID = new ResourceLocation(KCDCombat.MODID, "combat_state");

    @SubscribeEvent
    public static void onAttach(AttachCapabilitiesEvent<net.minecraft.world.entity.Entity> event) {
        if (event.getObject() instanceof Player) {
            event.addCapability(ID, new CombatCapabilityProvider());
        }
    }

    // Stamina/combat state should NOT persist through death (fresh stamina on respawn),
    // matching KCD where a fresh life starts unwinded. Left as a no-op placeholder;
    // flip to copy-from-original if you want stamina to survive respawn instead.
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        // intentionally empty
    }
}
