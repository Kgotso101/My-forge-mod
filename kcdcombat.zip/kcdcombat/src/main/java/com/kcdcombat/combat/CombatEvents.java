package com.kcdcombat.combat;

import com.kcdcombat.network.NetworkHandler;
import com.kcdcombat.network.packets.S2CStaminaSyncPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.List;

public class CombatEvents {

    // --- Tunables ---
    public static final int STRIKE_DURATION_TICKS = 6;      // travel time of the weapon once committed
    public static final int RECOVERY_DURATION_TICKS = 10;   // vulnerable lockout after a swing
    public static final int STAGGER_DURATION_TICKS = 22;    // extended lockout after being master-struck
    public static final int MASTER_STRIKE_WINDOW_TICKS = 4; // how "late" a block can start and still count as a perfect parry
    public static final float STAMINA_COST_ATTACK = 15f;
    public static final float STAMINA_COST_BLOCK_HIT = 8f;   // defender's stamina cost for a successful (non-master) block
    public static final double DEFAULT_WEAPON_REACH = 3.25;
    public static final double HIT_CONE_DOT_THRESHOLD = 0.75; // how tightly the attacker must be aiming at the target

    // ---------------- Packet entry points (called from network packet handlers) ----------------

    public static void startWindup(ServerPlayer player) {
        CombatCapability state = CombatCapabilities.get(player);
        if (state.getPhase() != AttackPhase.IDLE) return;
        if (state.getStamina() < STAMINA_COST_ATTACK * 0.25f) return; // too exhausted to even raise the weapon
        state.setPhase(AttackPhase.WINDUP);
    }

    public static void updateDirection(ServerPlayer player, CombatDirection direction) {
        CombatCapability state = CombatCapabilities.get(player);
        if (state.getPhase() == AttackPhase.WINDUP) {
            state.setAttackDirection(direction);
        }
    }

    public static void releaseStrike(ServerPlayer player) {
        CombatCapability state = CombatCapabilities.get(player);
        if (state.getPhase() != AttackPhase.WINDUP) return;
        if (!state.spendStamina(STAMINA_COST_ATTACK)) {
            // exhausted mid-windup: weapon drops, straight to recovery, no damage
            state.setPhase(AttackPhase.RECOVERY);
            return;
        }
        state.setPhase(AttackPhase.STRIKE);
    }

    public static void setBlocking(ServerPlayer player, boolean blocking, CombatDirection direction) {
        CombatCapability state = CombatCapabilities.get(player);
        if (state.getPhase() == AttackPhase.STRIKE) return; // can't raise a block mid-swing
        state.setBlockDirection(direction);
        state.setBlocking(blocking, player.tickCount);
    }

    // ---------------- Per-tick phase progression + stamina regen ----------------

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer sp)) return;

        CombatCapability state = CombatCapabilities.get(sp);
        state.tickRegen();

        switch (state.getPhase()) {
            case STRIKE -> {
                state.incrementPhaseTicks();
                if (state.getPhaseTicks() >= STRIKE_DURATION_TICKS) {
                    resolveHit(sp, state);
                    state.setPhase(AttackPhase.RECOVERY);
                }
            }
            case RECOVERY -> {
                state.incrementPhaseTicks();
                int duration = state.getLastSuccessfulBlockTick() == sp.tickCount ? STAGGER_DURATION_TICKS : RECOVERY_DURATION_TICKS;
                if (state.getPhaseTicks() >= duration) {
                    state.setPhase(AttackPhase.IDLE);
                }
            }
            default -> {}
        }

        // sync stamina to owner every few ticks (cheap enough to just do it each tick; throttle if needed)
        if (sp.tickCount % 4 == 0) {
            NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp),
                    new S2CStaminaSyncPacket(state.getStamina(), CombatCapability.MAX_STAMINA));
        }
    }

    // ---------------- Hit resolution ----------------

    private static void resolveHit(ServerPlayer attacker, CombatCapability attackerState) {
        ServerLevel level = attacker.serverLevel();
        Vec3 eye = attacker.getEyePosition();
        Vec3 look = attacker.getLookAngle();
        double reach = DEFAULT_WEAPON_REACH; // TODO: read from held weapon item once weapon registry exists

        List<LivingEntity> candidates = level.getEntitiesOfClass(LivingEntity.class,
                attacker.getBoundingBox().inflate(reach),
                e -> e != attacker && e.isAlive());

        LivingEntity target = null;
        double bestDot = HIT_CONE_DOT_THRESHOLD;
        for (LivingEntity e : candidates) {
            Vec3 toEntity = e.position().add(0, e.getBbHeight() / 2.0, 0).subtract(eye);
            double dist = toEntity.length();
            if (dist > reach) continue;
            Vec3 dir = toEntity.normalize();
            double dot = dir.dot(look);
            if (dot > bestDot) {
                bestDot = dot;
                target = e;
            }
        }

        if (target == null) return; // whiffed

        if (target instanceof ServerPlayer targetPlayer) {
            CombatCapability targetState = CombatCapabilities.get(targetPlayer);
            if (targetState.isBlocking() && targetState.getBlockDirection() == attackerState.getAttackDirection()) {
                int blockLatency = attacker.tickCount - targetState.getBlockStartTick();
                if (blockLatency >= 0 && blockLatency <= MASTER_STRIKE_WINDOW_TICKS) {
                    // MASTER STRIKE: perfectly-timed matching block staggers the attacker, defender takes no stamina loss
                    attackerState.setLastSuccessfulBlockTick(attacker.tickCount);
                    targetState.setLastSuccessfulBlockTick(attacker.tickCount); // reused as "just parried" marker for both
                    level.playSound(null, attacker.blockPosition(), net.minecraft.sounds.SoundEvents.SHIELD_BLOCK, net.minecraft.sounds.SoundSource.PLAYERS, 1.2f, 0.8f);
                    return;
                }
                // normal block: damage negated, both sides pay stamina
                targetState.spendStamina(STAMINA_COST_BLOCK_HIT);
                level.playSound(null, targetPlayer.blockPosition(), net.minecraft.sounds.SoundEvents.SHIELD_BLOCK, net.minecraft.sounds.SoundSource.PLAYERS, 1.0f, 1.0f);
                return;
            }
        }

        // unblocked hit: apply damage
        float damage = (float) attacker.getAttributeValue(Attributes.ATTACK_DAMAGE);
        DamageSource src = level.damageSources().playerAttack(attacker);
        target.hurt(src, damage);
        target.knockback(0.25, attacker.getX() - target.getX(), attacker.getZ() - target.getZ());
    }

    // Prevent vanilla's default swing-spam damage from double-dipping while this system is active.
    // (Left permissive for now — tighten once the weapon/item layer lands.)
    @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event) {
        // Hook point reserved for damage-type modifiers (armor piercing, weapon class vs. armor class, etc.)
    }
}
