package com.kcdcombat.combat;

import net.minecraft.nbt.CompoundTag;

public class CombatCapability {

    // --- Stamina ---
    public static final float MAX_STAMINA = 100f;
    public static final float STAMINA_REGEN_PER_TICK = 0.15f; // ~3/sec, halted briefly after spending
    public static final int REGEN_DELAY_TICKS = 15; // ticks after an action before regen resumes

    private float stamina = MAX_STAMINA;
    private int regenDelayTicks = 0;

    // --- Attack state ---
    private AttackPhase phase = AttackPhase.IDLE;
    private CombatDirection attackDirection = CombatDirection.TOP;
    private int phaseTicks = 0; // ticks spent in current phase

    // --- Block state ---
    private boolean blocking = false;
    private CombatDirection blockDirection = CombatDirection.TOP;
    private int blockStartTick = 0; // used for master-strike (perfect parry) timing window

    // --- Master strike bookkeeping ---
    private int lastSuccessfulBlockTick = -1000;

    public float getStamina() { return stamina; }

    public void setStamina(float value) {
        stamina = Math.max(0f, Math.min(MAX_STAMINA, value));
    }

    public boolean spendStamina(float amount) {
        if (stamina < amount) return false;
        stamina -= amount;
        regenDelayTicks = REGEN_DELAY_TICKS;
        return true;
    }

    public void tickRegen() {
        if (regenDelayTicks > 0) {
            regenDelayTicks--;
        } else if (stamina < MAX_STAMINA) {
            stamina = Math.min(MAX_STAMINA, stamina + STAMINA_REGEN_PER_TICK);
        }
    }

    public AttackPhase getPhase() { return phase; }
    public void setPhase(AttackPhase phase) { this.phase = phase; this.phaseTicks = 0; }
    public int getPhaseTicks() { return phaseTicks; }
    public void incrementPhaseTicks() { phaseTicks++; }

    public CombatDirection getAttackDirection() { return attackDirection; }
    public void setAttackDirection(CombatDirection dir) { this.attackDirection = dir; }

    public boolean isBlocking() { return blocking; }
    public void setBlocking(boolean blocking, int currentTick) {
        if (blocking && !this.blocking) this.blockStartTick = currentTick;
        this.blocking = blocking;
    }

    public CombatDirection getBlockDirection() { return blockDirection; }
    public void setBlockDirection(CombatDirection dir) { this.blockDirection = dir; }
    public int getBlockStartTick() { return blockStartTick; }

    public int getLastSuccessfulBlockTick() { return lastSuccessfulBlockTick; }
    public void setLastSuccessfulBlockTick(int tick) { this.lastSuccessfulBlockTick = tick; }

    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putFloat("stamina", stamina);
        return tag;
    }

    public void deserializeNBT(CompoundTag tag) {
        if (tag.contains("stamina")) stamina = tag.getFloat("stamina");
    }
}
