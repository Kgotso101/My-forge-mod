package com.kcdcombat.combat;

/**
 * The five directional lanes used for both attacks and blocks, matching
 * Kingdom Come: Deliverance's system. Attack direction and block direction
 * are compared directly: a block only stops an attack from the same lane.
 */
public enum CombatDirection {
    TOP,
    LEFT,
    RIGHT,
    BOTTOM,
    STAB; // thrust - no matching block lane in KCD; stabs are parried by any active block but deal reduced stamina damage, or dodged

    public static CombatDirection fromMouseDelta(double dx, double dy, boolean stabHeld) {
        if (stabHeld) return STAB;

        double absX = Math.abs(dx);
        double absY = Math.abs(dy);

        // Require a minimum flick magnitude before committing to a direction,
        // otherwise default to TOP (a light tap = overhead, matching KCD's rest direction).
        double magnitude = Math.sqrt(dx * dx + dy * dy);
        if (magnitude < 2.0) return TOP;

        if (absY >= absX) {
            return dy < 0 ? TOP : BOTTOM;
        } else {
            return dx < 0 ? LEFT : RIGHT;
        }
    }
}
