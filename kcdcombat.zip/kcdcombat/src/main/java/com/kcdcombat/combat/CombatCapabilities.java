package com.kcdcombat.combat;

import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;

public class CombatCapabilities {

    public static final Capability<CombatCapability> COMBAT_STATE =
            CapabilityManager.get(new CapabilityToken<>() {});

    /** Convenience accessor - throws if capability missing (should never happen for a Player after attach). */
    public static CombatCapability get(Player player) {
        return player.getCapability(COMBAT_STATE).orElseThrow(
                () -> new IllegalStateException("Player missing CombatCapability: " + player.getName().getString()));
    }
}
