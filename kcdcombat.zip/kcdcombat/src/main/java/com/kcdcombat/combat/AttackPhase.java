package com.kcdcombat.combat;

public enum AttackPhase {
    IDLE,       // weapon at rest
    WINDUP,     // key held, player choosing/committing direction via mouse flick
    STRIKE,     // committed, weapon travelling - direction now locked, cannot be changed
    RECOVERY    // post-hit or post-miss, vulnerable, brief lockout before next action
}
