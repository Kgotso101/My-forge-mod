package com.kcdcombat;

import com.kcdcombat.network.NetworkHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.api.distmarker.Dist;
import com.kcdcombat.combat.CombatEvents;
import com.kcdcombat.client.ClientCombatHandler;
import com.kcdcombat.client.KeyBindings;

@Mod(KCDCombat.MODID)
public class KCDCombat {

    public static final String MODID = "kcdcombat";

    public KCDCombat() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        NetworkHandler.register();

        // Server/common-side combat logic (stamina, hit resolution, state sync)
        MinecraftForge.EVENT_BUS.register(new CombatEvents());

        if (net.minecraftforge.fml.loading.FMLEnvironment.dist == Dist.CLIENT) {
            MinecraftForge.EVENT_BUS.register(new ClientCombatHandler());
            modEventBus.register(KeyBindings.class);
        }
    }
}
