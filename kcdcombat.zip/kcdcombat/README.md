# KCD-Style Combat (Forge 1.20.1)

## Setup
This isn't a runnable project by itself — it's the `src/` + Gradle config to drop into
a Forge 1.20.1 MDK (Mod Developer Kit).

1. Download the official Forge 1.20.1-47.2.0 MDK from files.minecraftforge.net.
2. Copy this project's `src/main/java/com/kcdcombat/...`, `src/main/resources/...`,
   and `build.gradle` over the MDK's equivalents (or merge if you've already customized the MDK).
3. In the project root: `./gradlew genEclipseRuns` (or `genIntellijRuns`) then `./gradlew runClient`.
   I couldn't run Gradle myself in this environment (no network access to fetch Forge/MDK), so
   this hasn't been compiled or tested — expect a couple of small fixes on first build (mainly
   import paths; Forge's 1.20.1 API shifts small things between minor versions).

## What's implemented (this pass)
- **Directional system**: 5 lanes (top/left/right/bottom/stab), matching KCD — a block only
  stops an attack from the same lane.
- **Attack flow**: hold Attack → WINDUP (flick mouse to pick direction) → release → STRIKE
  (direction locks, weapon travels) → hit resolution → RECOVERY (vulnerable lockout).
- **Blocking**: hold Block, angle mouse to set block direction; matching direction negates the hit.
- **Stamina**: capability-backed, spent on attacking and on absorbing blocked hits, regenerates
  after a short delay, synced to the client for HUD use.
- **Master strike (basic)**: if your block direction matches the incoming attack AND you started
  blocking within ~4 ticks of the swing landing, the attacker is staggered instead of you taking
  stamina loss (full riposte/free-hit follow-up isn't wired up yet).
- **Hit detection**: server-side raycast/cone check from the attacker at swing resolution — not
  yet per-weapon reach (fixed reach constant) and not real animated weapon-sweep collision.

## Deliberately not done yet (next passes)
- Per-weapon stats (reach, damage, swing speed, weight) — currently one fixed reach/damage for all weapons.
- HUD: directional indicator, stamina bar rendering (stamina values are synced and stored client-side, just not drawn).
- Player animations (KCD's stances/swing animations need a custom model or animation library — vanilla's arm swing won't look right for this).
- Master strike riposte (free guaranteed hit after a perfect parry).
- Clinch/grapple system, dodging, mounted combat, NPC AI using this same system.
- Weapon-vs-armor damage typing (blunt/slash/pierce vs plate/mail/cloth).

Given the actual size of KCD's combat, I'd suggest we tackle these in the same order as
"deliberately not done yet" above — weapons next, since damage/reach/speed feed into everything else.
